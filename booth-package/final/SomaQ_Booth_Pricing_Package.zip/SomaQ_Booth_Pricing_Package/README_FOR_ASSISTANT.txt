SOMA-Q BOOTH PRINT PACKAGE: FOR PRICING

Event: Saturday, October 24, 2026. This is Megan's first booth.

WHAT THIS IS
Pieces that are decided and ready to price. Quantities are not set yet, so SPEC_SHEET_for_pricing.csv has "TBD by Megan" in that column. Please ask for quotes at a few quantity breaks if the vendor allows.

WHAT IS IN HERE
files/      The print-ready PDFs, one folder per piece.
previews/   A picture of each piece, for quick looking.
SPEC_SHEET_for_pricing.csv    One row per piece: sizes, sides, and notes for the quote. Opens in Excel or Google Sheets.

THINGS TO ASK EVERY VENDOR
1. Their template or exact file size for each piece (the sizes here are Megan's best match to a standard size; the banner was prepared for a 32 x 80 in retractable banner).
2. Stock, finish, and turnaround. The booth is October 24, so ask for the latest date they can order by and still deliver in time.
3. Whether they want the bleed version or the trim version of each file.

STILL OPEN (Megan is confirming these; please do not order yet)
- The phone number on the business card back (303-717-9995) and the QR code links need Megan's final check. QR codes only work once the website redirects are live.
- The business card front is chosen (all white, serif paragraph).
- The luggage tag size and hole position, and the stand sign holder size, are not confirmed.
- The ™ on "Shift Happens" is waiting on Megan's attorney.

Questions: megan@soma-q.com
