SOMA-Q BOOTH PRINT FILES  (assembled Oct 13, 2026)
===================================================
All files are PDFs unless noted. Fonts are embedded. Colors are RGB (see note 6).

WHAT IS IN HERE
1_Postcard ............ Front v4 and Back v4. 6 x 4 in trim, file 6.25 x 4.25 in (0.125 in bleed).
2_Business_Card ....... Back v12, plus the two all-white fronts (pick ONE: BoldText or SerifText; not yet chosen). 3.5 x 2 in trim, file 3.75 x 2.25 in (0.125 in bleed).
3_Banner_32x80 ........ 32 x 80 in retractable banner. Use SomaQ_Banner_32x80_trim.pdf (exact trim size) or the 150 dpi PNG inside the zip.
                        SomaQ_Banner_33x81_with_bleed.pdf has 0.5 in bleed if your printer asks for bleed.
4_Table_Signs ......... Five Signs sign (Linen version, chosen) and Free Ebook sign. 8.5 x 11 in trim, file 8.75 x 11.25 in (0.125 in bleed).
5_Ebook_Display_Card .. 4 x 2.5 in card (0.125 in bleed) and the ebook PDF to print 1 or 2 display copies (10 pages, letter size).
6_Tabletop_Stand_Sign . 12 x 6 in insert for the slanted acrylic holder. No bleed.
7_Luggage_Tag ......... White tag (vertical logo). Check the vendor's die line and hole position.
                        Tell Claude which you choose and it will move the chosen file into the right folder. Do not print these until chosen.

NOT INCLUDED
Banner D1 (kept in the project under booth-package/banners/), the dark teal Five Signs sign (kept in booth-package/alternates/), the raffle sign and entry slip (drafts), and older versions.

CONFIRM BEFORE YOU ORDER
1. Phone number on the business card back: 303-717-9995. This came from the website Terms page; it has not been confirmed.
2. QR codes: the card back uses /go/site. The Five Signs (Linen) sign uses /go/overview, and the ebook sign and ebook card use /go/ebook.
   These redirects must exist on soma-q.com and point to the right pages BEFORE printing. The measurement overview download link and the
   live ebook link are still to be confirmed. Test-scan a printed proof of every QR code.
3. Banner on a retractable stand: the bottom few inches roll into the base. In this banner SOMA-Q.COM sits about 1.5 in above the bottom edge
   and the last lines of the paragraph about 3.5 in up. Ask FedEx how much is hidden. If it is more than about 1.5 in, ask Claude to raise the
   bottom text first.
4. Trademark symbols (Shift Happens, Burnout ends here): have your attorney confirm. Claude is not a lawyer.
5. Business card front: two all-white options are in 2_Business_Card. Pick one before ordering. The dark teal front was moved out of the final set.
6. Color: files are RGB. Printers convert to CMYK; dark teal may look slightly different on press. Ask for a proof if exact color matters.
7. The banner logo is a picture at about 115 pixels per inch at full size. Fine for a banner viewed from a distance; send an original vector
   logo (SVG, AI, or EPS) to Claude if you want it sharper.
